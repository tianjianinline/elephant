package com.psbc.elephant.configure;

/**
 * Spring Boot 依赖则自动启动加载.
 * @author sks
 *
 */
public class AutoConfiguration {

}
