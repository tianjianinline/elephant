package com.psbc.elephant.core;

/**
 * 利用Redis分布式锁实现令牌争抢.
 * @author sks
 *
 */
public class RedisLocker implements Locker{

	@Override
	public void lock() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unlock() {
		// TODO Auto-generated method stub
		
	}

}
