package com.psbc.elephant.core;

/**
 * 令牌锁定工具.
 * @author sks
 *
 */
public interface Locker {

	/**
	 * 获取令牌.
	 */
	void lock();
	
	/**
	 * 释放令牌.
	 */
	void unlock();
}
